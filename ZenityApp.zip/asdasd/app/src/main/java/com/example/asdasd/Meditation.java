package com.example.asdasd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;


public class Meditation extends AppCompatActivity {
    private static final String TAG = StartActivity.class.getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.meditation);
        Button deepBreating=findViewById(R.id.start_breathing_button);
        Button evening=findViewById(R.id.start_mindfulness_button);
        Button guided=findViewById(R.id.start_guided_meditation_button);
        Button morning=findViewById(R.id.start_morning_button);
        Button nature=findViewById(R.id.start_soundscapes_button);
        ImageView profile=findViewById(R.id.btnProfile);
        ImageView setting=findViewById(R.id.btnSetting);

        profile.setOnClickListener(v->{

            Intent intent=new Intent(this,Profile.class);
            startActivity(intent);

        });
        setting.setOnClickListener(v->{

            Intent intent=new Intent(this,Setting.class);
            startActivity(intent);

        });



        deepBreating.setOnClickListener(v->{

            Intent intent=new Intent(this,DeepBreathing.class);
            startActivity(intent);

        });
        evening.setOnClickListener(v->{

            Intent intent=new Intent(this,EveningMindfulness.class);
            startActivity(intent);

        });
        guided.setOnClickListener(v->{

            Intent intent=new Intent(this,GuidedMeditation.class);
            startActivity(intent);

        });
        morning.setOnClickListener(v->{

            Intent intent=new Intent(this,MorningRelaxation.class);
            startActivity(intent);

        });
        nature.setOnClickListener(v->{

            Intent intent=new Intent(this,NatureSoundScape.class);
            startActivity(intent);

        });



    }


}