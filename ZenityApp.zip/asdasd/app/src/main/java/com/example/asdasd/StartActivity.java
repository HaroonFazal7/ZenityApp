package com.example.asdasd;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;


public class StartActivity extends AppCompatActivity {
    private static final String TAG = StartActivity.class.getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.start);

        AppCompatButton login=findViewById(R.id.btnLogin);
        AppCompatButton signUp=findViewById(R.id.btnSignUp);

        login.setOnClickListener(v->{

            Intent intent=new Intent(this,Login.class);
            startActivity(intent);

        });

        signUp.setOnClickListener(v->{

            Intent intent=new Intent(this,SignUp.class);
            startActivity(intent);

        });

    }


}