package com.example.asdasd;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MorningRelaxation extends AppCompatActivity {


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.morning_relaxation);
        Button btn=findViewById(R.id.start_session_button);
        btn.setOnClickListener(v -> {

            Intent intent=new Intent(this,SelectionScreen.class);
            startActivity(intent);


        });


    }
}