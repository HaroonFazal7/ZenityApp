package com.example.asdasd;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;


public class SignUp extends AppCompatActivity {
    private static final String TAG = StartActivity.class.getSimpleName();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        AppCompatButton btn=findViewById(R.id.create);
        btn.setOnClickListener(v->{

            Intent intent=new Intent(this,Meditation.class);
            startActivity(intent);

        });

    }


}